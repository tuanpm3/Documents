#include <src/inc/header.h>
#include <gtest/gtest.h>
#include <gmock/gmock.h>


/********************************************************/
/*							Test Case	 					*/
/********************************************************/
TEST(TEST, TEST01)
{
	EXPECT_TRUE(test(1, 2) == 2);
}


/*-----Execute test------------------------*/
int main(int argc, char** argv)
{	
	::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
