int test (int x, int y) {
	if (x > y)
		return x;
	else
		return y;
}